#!/usr/bin/env python3
"""
TQWG Protocol Manager
Integrates all layers: handshake + crypto + obfuscation + transport
"""

import asyncio
import hashlib
import logging
from typing import Optional, Callable, Dict, Tuple
from dataclasses import dataclass

from .handshake import TQWGHandshake, MessageType
from .crypto import TQWGCryptoSession
from .obfuscation import TQWGObfuscator, ObfMode
from .transport import TQWGTransport

logger = logging.getLogger('TQWGProtocol')


@dataclass
class PeerSession:
    """Active peer session"""
    addr: Tuple[str, int]
    handshake: TQWGHandshake
    crypto: TQWGCryptoSession
    obf: TQWGObfuscator
    authenticated: bool = False
    session_id: Optional[bytes] = None


class TQWGProtocol:
    """
    TQWG Protocol Manager

    Coordinates handshake, encryption, obfuscation, and transport
    """

    def __init__(self, host: str, port: int, is_server: bool = False,
                 static_key: Optional[bytes] = None,
                 obf_mode: ObfMode = ObfMode.XOR,
                 remote_pubkey_hex: Optional[str] = None):
        """
        Args:
            remote_pubkey_hex: For client, the server's public key hex string.
                               Used to derive obfuscation key.
        """
        self.is_server = is_server
        self.host = host
        self.port = port

        # Components
        self.handshake = TQWGHandshake(static_key)
        self.crypto = TQWGCryptoSession()
        # Derive obfuscation key from remote public key (client) or own public key (server)
        if remote_pubkey_hex:
            obf_key = hashlib.sha256(bytes.fromhex(remote_pubkey_hex)).digest()
        else:
            obf_key = hashlib.sha256(self.handshake.static_public_bytes).digest()
        self.obf = TQWGObfuscator(obf_mode, obf_key)

        self.transport = TQWGTransport(host, port)

        # State
        self.peers: Dict[str, PeerSession] = {}  # addr -> session
        self.on_data: Optional[Callable[[bytes, Tuple], None]] = None

        # Server specific
        self.expected_client_key: Optional[bytes] = None  # For authorized clients

    def set_data_handler(self, callback: Callable[[bytes, Tuple], None]):
        """Set callback for received data"""
        self.on_data = callback

    def authorize_client(self, client_pubkey_hex: str):
        """Authorize a client (server only)"""
        self.expected_client_key = bytes.fromhex(client_pubkey_hex)
        logger.info(f"Authorized client: {client_pubkey_hex[:16]}...")

    async def start(self):
        """Start protocol"""
        # Set packet handler
        self.transport.set_packet_handler(self._on_packet)

        # Start transport
        await self.transport.start()

        logger.info(f"TQWG Protocol started on {self.host}:{self.port}")
        logger.info(f"Mode: {'SERVER' if self.is_server else 'CLIENT'}")
        logger.info(f"Obfuscation: {self.obf.mode.name}")
        logger.info(f"Public Key: {self.handshake.get_public_key_hex()[:32]}...")

    async def connect_to(self, host: str, port: int,
                        server_pubkey_hex: str) -> bool:
        """
        Connect to server (client only)

        Returns True if handshake successful
        """
        server_addr = (host, port)
        server_pubkey = bytes.fromhex(server_pubkey_hex)

        logger.info(f"Connecting to {server_addr}")

        # Create peer session using client's static key
        client_priv_bytes = self.handshake.get_private_key_bytes()
        peer_key = f"{host}:{port}"
        peer = PeerSession(
            addr=server_addr,
            handshake=TQWGHandshake(client_priv_bytes),  # Use same static key
            crypto=TQWGCryptoSession(),
            obf=self.obf  # Share obfuscator (same key)
        )
        self.peers[peer_key] = peer

        # Send initiation
        init_packet = peer.handshake.create_initiation()
        obf_packet = peer.obf.obfuscate(init_packet)

        await self.transport.send(obf_packet, server_addr)

        # Wait for authentication with timeout
        try:
            await asyncio.wait_for(self._wait_for_auth(peer), timeout=10.0)
            return True
        except asyncio.TimeoutError:
            logger.error("Handshake timeout")
            return False

    async def _wait_for_auth(self, peer: PeerSession):
        """Wait until peer is authenticated"""
        while not peer.authenticated:
            await asyncio.sleep(0.1)

    async def _on_packet(self, data: bytes, addr: Tuple[str, int]):
        """Handle incoming packet"""
        peer_key = f"{addr[0]}:{addr[1]}"

        # Get or create peer
        if peer_key not in self.peers:
            if not self.is_server:
                logger.warning(f"Unexpected packet from {addr}")
                return

            # New client
            self.peers[peer_key] = PeerSession(
                addr=addr,
                handshake=TQWGHandshake(),  # Server uses its own static key
                crypto=TQWGCryptoSession(),
                obf=self.obf  # Share obfuscator
            )

        peer = self.peers[peer_key]

        # Deobfuscate
        deobf = peer.obf.deobfuscate(data)
        if deobf is None:
            logger.warning(f"Deobfuscation failed from {addr}")
            return

        # Check message type
        if len(deobf) == 0:
            return

        msg_type = deobf[0]

        if msg_type == MessageType.INITIATION:
            await self._handle_initiation(peer, deobf, addr)
        elif msg_type == MessageType.RESPONSE:
            await self._handle_response(peer, deobf, addr)
        elif msg_type in [MessageType.DATA, MessageType.KEEPALIVE]:
            await self._handle_data(peer, deobf, addr)
        else:
            logger.warning(f"Unknown message type {msg_type} from {addr}")

    async def _handle_initiation(self, peer: PeerSession, data: bytes,
                                  addr: Tuple[str, int]):
        """Handle client initiation (server only)"""
        if not self.is_server:
            return

        logger.info(f"Handshake initiation from {addr}")

        # Process initiation
        result = self.handshake.process_initiation(data)
        if not result:
            logger.warning(f"Invalid initiation from {addr}")
            return

        response, send_key, recv_key, client_pubkey = result

        # Check authorization if set
        if self.expected_client_key and client_pubkey != self.expected_client_key:
            logger.warning(f"Unauthorized client: {client_pubkey.hex()[:16]}")
            return

        # Setup crypto
        session_id = peer.crypto.create_session(send_key, recv_key)
        peer.session_id = session_id
        peer.authenticated = True

        # Send response
        obf_response = peer.obf.obfuscate(response)
        await self.transport.send(obf_response, addr)

        logger.info(f"Handshake complete with {addr}")

    async def _handle_response(self, peer: PeerSession, data: bytes,
                                addr: Tuple[str, int]):
        """Handle server response (client only)"""
        if self.is_server:
            return

        logger.info(f"Handshake response from {addr}")

        # Get expected server key (stored in connect_to)
        expected_key = None  # We'll need to pass it; for now use peer's handshake?
        # Actually we can store server pubkey in peer or protocol.
        # For simplicity, we assume peer.handshake has no expected key.
        # In a full implementation, we should pass it.

        # Process response
        if peer.handshake.process_response(data, None):  # Simplified
            keys = peer.handshake.get_derived_keys()
            if keys:
                send_key, recv_key = keys
                session_id = peer.crypto.create_session(send_key, recv_key)
                peer.session_id = session_id
                peer.authenticated = True
                logger.info(f"Authenticated with {addr}")
        else:
            logger.warning(f"Handshake failed with {addr}")

    async def _handle_data(self, peer: PeerSession, data: bytes,
                            addr: Tuple[str, int]):
        """Handle encrypted data"""
        if not peer.authenticated:
            logger.warning(f"Data from unauthenticated peer {addr}")
            return

        # Decrypt
        plaintext = peer.crypto.decrypt(data)
        if plaintext is None:
            logger.warning(f"Decryption failed from {addr}")
            return

        # Call handler
        if self.on_data:
            self.on_data(plaintext, addr)

    async def send_data(self, data: bytes, addr: Optional[Tuple[str, int]] = None) -> bool:
        """Send encrypted data"""
        # Find peer
        if addr:
            peer_key = f"{addr[0]}:{addr[1]}"
            peer = self.peers.get(peer_key)
        else:
            # Use first authenticated peer
            peer = None
            for p in self.peers.values():
                if p.authenticated:
                    peer = p
                    addr = p.addr
                    break

        if not peer or not peer.authenticated:
            logger.error("No authenticated peer")
            return False

        # Encrypt
        encrypted = peer.crypto.encrypt(data, peer.session_id)
        if not encrypted:
            return False

        # Obfuscate
        obf = peer.obf.obfuscate(encrypted)

        # Send
        return await self.transport.send(obf, addr)

    def get_stats(self) -> dict:
        """Get protocol statistics"""
        return {
            'peers': len(self.peers),
            'authenticated': sum(1 for p in self.peers.values() if p.authenticated),
            'public_key': self.handshake.get_public_key_hex()[:16],
            'transport': self.transport.get_stats()
        }