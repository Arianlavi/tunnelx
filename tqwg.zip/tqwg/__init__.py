#!/usr/bin/env python3
"""
TQWG - TunnelX
A novel VPN protocol with automatic handshake and pluggable obfuscation
"""

__version__ = "1.0.0"
__author__ = "ARIAN LAVI"

from .crypto import TQWGCryptoSession
from .handshake import TQWGHandshake
from .obfuscation import TQWGObfuscator, ObfMode
from .protocol import TQWGProtocol
from .transport import TQWGTransport

__all__ = [
    "TQWGCryptoSession",
    "TQWGHandshake", 
    "TQWGObfuscator",
    "ObfMode",
    "TQWGProtocol",
    "TQWGTransport",
]