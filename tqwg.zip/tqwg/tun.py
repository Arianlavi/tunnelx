#!/usr/bin/env python3
"""
TQWG TUN Interface
Linux TUN/TAP for system-wide VPN
"""

import os
import fcntl
import struct
import subprocess


class TQWGTun:
    """Linux TUN interface handler"""
    
    TUNSETIFF = 0x400454ca
    IFF_TUN = 0x0001
    IFF_NO_PI = 0x1000
    IFF_UP = 0x1
    
    def __init__(self, name: str = "tqwg0"):
        self.name = name
        self.fd = -1
        self.mtu = 1400  # Leave room for headers
        
    def create(self) -> bool:
        """Create TUN interface"""
        try:
            self.fd = os.open("/dev/net/tun", os.O_RDWR)
            
            # Configure
            ifr = struct.pack("16sH", self.name.encode(), self.IFF_TUN | self.IFF_NO_PI)
            fcntl.ioctl(self.fd, self.TUNSETIFF, ifr)
            
            print(f"[*] Created interface {self.name}")
            return True
            
        except Exception as e:
            print(f"[!] TUN creation failed: {e}")
            print("[!] Run: sudo modprobe tun")
            return False
    
    def configure(self, local_ip: str, peer_ip: str) -> bool:
        """Set IP addresses"""
        try:
            # Bring up
            subprocess.run(["ip", "link", "set", self.name, "up"], check=True)
            
            # Set IP
            subprocess.run(["ip", "addr", "add", f"{local_ip}/24", "dev", self.name], check=True)
            
            # MTU
            subprocess.run(["ip", "link", "set", self.name, "mtu", str(self.mtu)], check=True)
            
            # Route all traffic through TUN (optional)
            # subprocess.run(["ip", "route", "add", "default", "dev", self.name], check=True)
            
            print(f"[*] Configured {self.name}: {local_ip} -> {peer_ip}")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"[!] Configuration failed: {e}")
            return False
    
    def read(self) -> Optional[bytes]:
        """Read packet from TUN"""
        try:
            return os.read(self.fd, 65535)
        except Exception as e:
            print(f"[!] TUN read error: {e}")
            return None
    
    def write(self, data: bytes) -> bool:
        """Write packet to TUN"""
        try:
            os.write(self.fd, data)
            return True
        except Exception as e:
            print(f"[!] TUN write error: {e}")
            return False
    
    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            subprocess.run(["ip", "link", "del", self.name], capture_output=True)