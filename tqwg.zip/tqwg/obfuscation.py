#!/usr/bin/env python3
"""
TQWG Obfuscation Layer
Pluggable traffic obfuscation to evade DPI
"""

import random
import struct
import secrets
import logging
from enum import IntEnum
from typing import Optional

logger = logging.getLogger('TQWGObfuscation')


class ObfMode(IntEnum):
    """Obfuscation modes"""
    NONE = 0           # No obfuscation (for testing)
    XOR = 1            # Simple XOR stream
    TLS_MIMIC = 2      # Mimic TLS 1.3 records
    HTTP_MIMIC = 3     # Mimic HTTP requests
    DNS_MIMIC = 4      # Mimic DNS queries
    RANDOM_PADDING = 5 # Random padding only


class TQWGObfuscator:
    """
    TQWG Traffic Obfuscator
    
    Transforms TQWG packets to resemble other protocols,
    making them harder to detect and block.
    """
    
    def __init__(self, mode: ObfMode = ObfMode.XOR, key: Optional[bytes] = None):
        self.mode = mode
        self.key = key or secrets.token_bytes(32)
        self.packet_count = 0
        self.logger = logging.getLogger(f'TQWGObfuscation.{mode.name}')
        
        self.logger.info(f"Initialized with mode {mode.name}")
    
    def set_key(self, key: bytes):
        """Set obfuscation key"""
        self.key = key[:32]  # Ensure 32 bytes
    
    def obfuscate(self, data: bytes) -> bytes:
        """
        Apply obfuscation to data
        
        Returns obfuscated packet ready for transmission
        """
        if self.mode == ObfMode.NONE:
            return self._add_header(data, ObfMode.NONE)
        
        elif self.mode == ObfMode.XOR:
            obf_data = self._xor_stream(data)
            return self._add_header(obf_data, ObfMode.XOR)
        
        elif self.mode == ObfMode.TLS_MIMIC:
            obf_data = self._tls_mimic(data)
            return obf_data  # TLS has its own structure
        
        elif self.mode == ObfMode.HTTP_MIMIC:
            obf_data = self._http_mimic(data)
            return obf_data
        
        elif self.mode == ObfMode.DNS_MIMIC:
            obf_data = self._dns_mimic(data)
            return obf_data
        
        elif self.mode == ObfMode.RANDOM_PADDING:
            obf_data = self._random_padding(data)
            return self._add_header(obf_data, ObfMode.RANDOM_PADDING)
        
        else:
            return self._add_header(data, ObfMode.NONE)
    
    def deobfuscate(self, data: bytes) -> Optional[bytes]:
        """
        Remove obfuscation and return original data
        
        Returns None if data is invalid
        """
        if len(data) < 5:
            return None
        
        # Check for TLS/HTTP/DNS (no header)
        if data[0] == 0x17 or data[0] == 0x16:  # TLS record
            return self._tls_unwrap(data)
        
        if data[:4] == b'POST' or data[:3] == b'GET':
            return self._http_unwrap(data)
        
        # Check for DNS (first 2 bytes are length)
        if len(data) > 12 and data[2:4] == b'\x01\x00':  # Standard query
            return self._dns_unwrap(data)
        
        # Standard header format
        try:
            mode_byte = data[0]
            length = struct.unpack(">I", data[1:5])[0]
            payload = data[5:]
            
            if len(payload) != length:
                self.logger.warning(f"Length mismatch: expected {length}, got {len(payload)}")
                return None
            
            mode = ObfMode(mode_byte)
            
            if mode == ObfMode.NONE:
                return payload
            elif mode == ObfMode.XOR:
                return self._xor_stream(payload)  # XOR is symmetric
            elif mode == ObfMode.RANDOM_PADDING:
                return self._remove_padding(payload)
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Deobfuscation failed: {e}")
            return None
    
    def _add_header(self, data: bytes, mode: ObfMode) -> bytes:
        """Add obfuscation header"""
        # Format: [mode(1)][length(4)][data(variable)]
        return bytes([mode]) + struct.pack(">I", len(data)) + data
    
    def _xor_stream(self, data: bytes) -> bytes:
        """
        XOR with rotating key
        
        Similar to ChaCha20 but simpler
        """
        result = bytearray()
        key_len = len(self.key)
        
        for i, byte in enumerate(data):
            # Key rotation: position-based mixing
            key_byte = self.key[i % key_len]
            rotation = ((i * 7) + (self.packet_count * 13)) & 0xFF
            result.append(byte ^ key_byte ^ rotation)
        
        self.packet_count += 1
        return bytes(result)
    
    def _tls_mimic(self, data: bytes) -> bytes:
        """
        Mimic TLS 1.3 Application Data record
        
        Makes TQWG traffic look like HTTPS
        """
        # TLS record header
        content_type = 0x17  # Application Data
        legacy_version = 0x0303  # TLS 1.2 (for compatibility)
        
        # Inner plaintext structure (TLS 1.3 style)
        inner_type = 0x17  # Application Data
        padding_size = random.randint(16, 256)
        
        # Embed our data in the "encrypted" payload
        # Format: [our_data][padding][inner_type]
        inner = data + bytes([0x00] * padding_size) + bytes([inner_type])
        
        # Fake auth tag (16 bytes) - looks like AEAD tag
        fake_tag = secrets.token_bytes(16)
        
        # Record header
        record = struct.pack(">BHH", content_type, legacy_version, len(inner) + 16)
        
        return record + inner + fake_tag
    
    def _tls_unwrap(self, data: bytes) -> Optional[bytes]:
        """Remove TLS wrapper"""
        if len(data) < 22:  # 5 header + 1 inner + 16 tag minimum
            return None
        
        # Skip header (5 bytes)
        # Read length and verify
        try:
            content_type = data[0]
            if content_type not in [0x17, 0x16]:  # Application Data or Handshake
                return None
            
            length = struct.unpack(">H", data[3:5])[0]
            inner = data[5:5+length-16]  # Exclude fake tag
            tag = data[5+length-16:5+length]
            
            # Find actual data (before padding zeros)
            # Last non-zero byte before final inner_type should be our data
            if len(inner) < 2:
                return None
            
            # Remove trailing inner_type byte
            inner = inner[:-1]
            
            # Remove padding (trailing zeros)
            while inner and inner[-1] == 0:
                inner = inner[:-1]
            
            return inner
            
        except Exception as e:
            self.logger.error(f"TLS unwrap failed: {e}")
            return None
    
    def _http_mimic(self, data: bytes) -> bytes:
        """Mimic HTTP POST request"""
        # Random path
        path = f"/api/v{random.randint(1,3)}/{secrets.token_hex(8)}"
        
        # Random headers
        headers = (
            f"POST {path} HTTP/1.1\r\n"
            f"Host: {random.choice(['cdn', 'api', 'gateway'])}.example.com\r\n"
            f"Content-Type: application/octet-stream\r\n"
            f"Content-Length: {len(data)}\r\n"
            f"X-Request-ID: {secrets.token_hex(16)}\r\n"
            f"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
            f"\r\n"
        ).encode()
        
        return headers + data
    
    def _http_unwrap(self, data: bytes) -> Optional[bytes]:
        """Remove HTTP wrapper"""
        try:
            # Find end of headers
            header_end = data.find(b'\r\n\r\n')
            if header_end == -1:
                return None
            
            body = data[header_end + 4:]
            
            # Check Content-Length if present
            # (simplified - just return body)
            return body
            
        except Exception:
            return None
    
    def _dns_mimic(self, data: bytes) -> bytes:
        """Mimic DNS query (for UDP only)"""
        # DNS header
        transaction_id = secrets.token_bytes(2)
        flags = b'\x01\x00'  # Standard query
        questions = struct.pack(">H", 1)
        answer_rrs = b'\x00\x00'
        authority_rrs = b'\x00\x00'
        additional_rrs = b'\x00\x00'
        
        # Fake domain name (encode our data)
        # Split data into labels (max 63 bytes each)
        labels = []
        for i in range(0, len(data), 63):
            chunk = data[i:i+63]
            labels.append(bytes([len(chunk)]) + chunk)
        
        domain = b''.join(labels) + b'\x00'
        
        # Query type A, class IN
        query_type = struct.pack(">HH", 1, 1)
        
        header = transaction_id + flags + questions + answer_rrs + authority_rrs + additional_rrs
        question = domain + query_type
        
        # Length prefix for TCP DNS (if needed)
        total_len = len(header) + len(question)
        
        return struct.pack(">H", total_len) + header + question
    
    def _dns_unwrap(self, data: bytes) -> Optional[bytes]:
        """Remove DNS wrapper"""
        try:
            # Skip length prefix (2 bytes) if present
            if len(data) > 2:
                data = data[2:]
            
            # Skip header (12 bytes)
            if len(data) < 12:
                return None
            
            # Parse question section to extract our data
            offset = 12
            
            # Read labels until null byte
            extracted = bytearray()
            while offset < len(data):
                label_len = data[offset]
                if label_len == 0:
                    break
                offset += 1
                extracted.extend(data[offset:offset+label_len])
                offset += label_len
            
            return bytes(extracted)
            
        except Exception:
            return None
    
    def _random_padding(self, data: bytes) -> bytes:
        """Add random padding to change packet size"""
        # Pad to random size between 512 and 1500 bytes
        target_size = random.randint(512, 1500)
        if len(data) >= target_size:
            return data
        
        padding_size = target_size - len(data) - 2  # 2 bytes for length
        padding = secrets.token_bytes(padding_size)
        
        # Format: [orig_len(2)][data][padding]
        return struct.pack(">H", len(data)) + data + padding
    
    def _remove_padding(self, data: bytes) -> Optional[bytes]:
        """Remove random padding"""
        if len(data) < 2:
            return None
        
        orig_len = struct.unpack(">H", data[:2])[0]
        return data[2:2+orig_len]
    
    def get_stats(self) -> dict:
        """Get obfuscation statistics"""
        return {
            'mode': self.mode.name,
            'packet_count': self.packet_count,
            'key_preview': self.key[:8].hex()
        }