#!/usr/bin/env python3
"""
TQWG Handshake Layer
Noise_IK pattern with automatic key negotiation
"""

import os
import time
import struct
import hashlib
import secrets
import logging
from typing import Optional, Tuple, Dict
from dataclasses import dataclass
from enum import IntEnum

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey, X25519PublicKey
)
from cryptography.hazmat.primitives import serialization

logger = logging.getLogger('TQWGHandshake')


class MessageType(IntEnum):
    """TQWG message types"""
    INITIATION = 0x01
    RESPONSE = 0x02
    DATA = 0x03
    REKEY = 0x04
    KEEPALIVE = 0x05


@dataclass
class HandshakeState:
    """State during handshake process"""
    ephemeral_private: X25519PrivateKey
    ephemeral_public: X25519PublicKey
    static_private: X25519PrivateKey
    static_public: X25519PublicKey
    remote_ephemeral: Optional[X25519PublicKey] = None
    remote_static: Optional[X25519PublicKey] = None
    completed: bool = False
    timestamp: float = 0.0


class TQWGHandshake:
    """
    TQWG Handshake Implementation
    Implements Noise_IK pattern with 1-RTT handshake
    """

    PROTOCOL_NAME = b"TQWG-v1-Noise_IK"
    HANDSHAKE_TIMEOUT = 30  # seconds

    # Message sizes
    EPHEMERAL_SIZE = 32
    STATIC_SIZE = 32
    TIMESTAMP_SIZE = 8
    MAC_SIZE = 16

    def __init__(self, static_private: Optional[bytes] = None):
        """
        Initialize handshake with static keypair

        Args:
            static_private: Optional private key bytes (generated if None)
        """
        if static_private:
            self.static_private = X25519PrivateKey.from_private_bytes(static_private)
            self.static_private_bytes = static_private
        else:
            self.static_private = X25519PrivateKey.generate()
            self.static_private_bytes = self.static_private.private_bytes_raw()

        self.static_public = self.static_private.public_key()
        self.static_public_bytes = self.static_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

        # Current handshake state
        self.state: Optional[HandshakeState] = None

        # Derived keys after handshake
        self.send_key: Optional[bytes] = None
        self.recv_key: Optional[bytes] = None

        logger.info(f"Initialized with public key: {self.get_public_key_hex()[:16]}...")

    def get_public_key_hex(self) -> str:
        """Get hex representation of public key"""
        return self.static_public_bytes.hex()

    def get_public_key_hash(self) -> str:
        """Get short hash for identification"""
        return hashlib.sha256(self.static_public_bytes).hexdigest()[:16]

    def get_private_key_bytes(self) -> bytes:
        """Get raw private key bytes"""
        return self.static_private_bytes

    def create_initiation(self) -> bytes:
        """
        Create handshake initiation message (client -> server)

        Format:
        [type(1)][version(1)][ephemeral(32)][static(32)][timestamp(8)][reserved(8)][mac(16)]
        Total: 98 bytes
        """
        # Generate ephemeral keypair
        ephemeral_private = X25519PrivateKey.generate()
        ephemeral_public = ephemeral_private.public_key()
        ephemeral_bytes = ephemeral_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

        # Save state
        self.state = HandshakeState(
            ephemeral_private=ephemeral_private,
            ephemeral_public=ephemeral_public,
            static_private=self.static_private,
            static_public=self.static_public,
            timestamp=time.time()
        )

        # Build message
        version = 0x01
        timestamp = struct.pack(">Q", int(time.time()))
        reserved = b'\x00' * 8  # For future extensions

        payload = (
            bytes([MessageType.INITIATION, version]) +
            ephemeral_bytes +
            self.static_public_bytes +
            timestamp +
            reserved
        )

        # Calculate MAC using static key
        mac_key = self._derive_mac_key(self.static_public_bytes, b"initiation")
        mac = hashlib.blake2b(payload, key=mac_key, digest_size=self.MAC_SIZE).digest()

        packet = payload + mac
        logger.debug(f"Created initiation: {len(packet)} bytes, type={MessageType.INITIATION}")

        return packet

    def process_initiation(self, data: bytes) -> Optional[Tuple[bytes, bytes, bytes, bytes]]:
        """
        Process client initiation and create response (server side)

        Returns:
            (response_packet, send_key, recv_key, client_public_key) or None if invalid
        """
        if len(data) < 98:
            logger.warning(f"Initiation too short: {len(data)} bytes")
            return None

        # Parse message
        msg_type = data[0]
        version = data[1]

        if msg_type != MessageType.INITIATION:
            logger.warning(f"Invalid message type: {msg_type}")
            return None

        if version != 0x01:
            logger.warning(f"Unsupported version: {version}")
            return None

        ephemeral_bytes = data[2:34]
        static_bytes = data[34:66]
        timestamp = data[66:74]
        reserved = data[74:82]
        mac = data[82:98]

        # Verify MAC
        payload = data[:82]
        mac_key = self._derive_mac_key(static_bytes, b"initiation")
        expected_mac = hashlib.blake2b(payload, key=mac_key, digest_size=self.MAC_SIZE).digest()

        if not secrets.compare_digest(mac, expected_mac):
            logger.warning("MAC verification failed")
            return None

        # Verify timestamp (anti-replay)
        ts_val = struct.unpack(">Q", timestamp)[0]
        if abs(time.time() - ts_val) > self.HANDSHAKE_TIMEOUT:
            logger.warning("Handshake timestamp expired")
            return None

        # Parse client keys
        try:
            client_ephemeral = X25519PublicKey.from_public_bytes(ephemeral_bytes)
            client_static = X25519PublicKey.from_public_bytes(static_bytes)
        except Exception as e:
            logger.error(f"Invalid client keys: {e}")
            return None

        # Generate server ephemeral
        server_ephemeral_private = X25519PrivateKey.generate()
        server_ephemeral_public = server_ephemeral_private.public_key()
        server_ephemeral_bytes = server_ephemeral_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

        # DH calculations (Noise IK pattern)
        # es: ephemeral-server to static-client
        es = server_ephemeral_private.exchange(client_static)
        # ss: static-server to static-client
        ss = self.static_private.exchange(client_static)
        # ee: ephemeral to ephemeral
        ee = server_ephemeral_private.exchange(client_ephemeral)

        # Combine and derive master secret
        dh_result = es + ss + ee
        master = hashlib.sha3_256(dh_result + self.PROTOCOL_NAME).digest()

        # Derive directional keys
        # Server sends with "server-to-client" key
        send_key = hashlib.sha256(master + b"server-to-client").digest()
        # Server receives with "client-to-server" key
        recv_key = hashlib.sha256(master + b"client-to-server").digest()

        # Build response
        resp_version = 0x01
        resp_timestamp = struct.pack(">Q", int(time.time()))
        resp_reserved = b'\x00' * 8

        # Include server static for client verification
        resp_payload = (
            bytes([MessageType.RESPONSE, resp_version]) +
            server_ephemeral_bytes +
            self.static_public_bytes +  # Server identity
            resp_timestamp +
            resp_reserved
        )

        # MAC with derived key
        resp_mac_key = hashlib.sha256(send_key).digest()
        resp_mac = hashlib.blake2b(resp_payload, key=resp_mac_key[:16], digest_size=self.MAC_SIZE).digest()

        response = resp_payload + resp_mac

        logger.info(f"Handshake accepted from {static_bytes.hex()[:16]}...")

        return response, send_key, recv_key, static_bytes

    def process_response(self, data: bytes, expected_server_key: Optional[bytes] = None) -> bool:
        """
        Process server response and complete handshake (client side)

        Args:
            data: Response packet from server
            expected_server_key: Optional expected server public key for verification

        Returns:
            True if handshake successful, False otherwise
        """
        if not self.state:
            logger.error("No handshake in progress")
            return False

        if len(data) < 98:
            logger.warning(f"Response too short: {len(data)} bytes")
            return False

        # Parse response
        msg_type = data[0]
        version = data[1]

        if msg_type != MessageType.RESPONSE:
            logger.warning(f"Invalid response type: {msg_type}")
            return False

        ephemeral_bytes = data[2:34]
        static_bytes = data[34:66]
        timestamp = data[66:74]
        reserved = data[74:82]
        mac = data[82:98]

        # Verify server identity if expected key provided
        if expected_server_key and static_bytes != expected_server_key:
            logger.error("Server identity mismatch!")
            return False

        # Parse server keys
        try:
            server_ephemeral = X25519PublicKey.from_public_bytes(ephemeral_bytes)
            server_static = X25519PublicKey.from_public_bytes(static_bytes)
        except Exception as e:
            logger.error(f"Invalid server keys: {e}")
            return False

        # Verify timestamp
        ts_val = struct.unpack(">Q", timestamp)[0]
        if abs(time.time() - ts_val) > self.HANDSHAKE_TIMEOUT:
            logger.warning("Response timestamp expired")
            return False

        # DH calculations (mirror of server)
        hs = self.state

        # es: ephemeral-client to static-server
        es = hs.ephemeral_private.exchange(server_static)
        # ss: static-client to static-server
        ss = hs.static_private.exchange(server_static)
        # ee: ephemeral to ephemeral
        ee = hs.ephemeral_private.exchange(server_ephemeral)

        # Derive same master secret
        dh_result = es + ss + ee
        master = hashlib.sha3_256(dh_result + self.PROTOCOL_NAME).digest()

        # Derive keys (reverse of server)
        # Client sends with "client-to-server" key
        self.send_key = hashlib.sha256(master + b"client-to-server").digest()
        # Client receives with "server-to-client" key
        self.recv_key = hashlib.sha256(master + b"server-to-client").digest()

        # Verify MAC
        payload = data[:82]
        mac_key = hashlib.sha256(self.recv_key).digest()
        expected_mac = hashlib.blake2b(payload, key=mac_key[:16], digest_size=self.MAC_SIZE).digest()

        if not secrets.compare_digest(mac, expected_mac):
            logger.error("Response MAC verification failed")
            return False

        # Success!
        self.state.completed = True
        self.state.remote_ephemeral = server_ephemeral
        self.state.remote_static = server_static

        logger.info("Handshake completed successfully")

        return True

    def _derive_mac_key(self, public_key: bytes, context: bytes) -> bytes:
        """Derive MAC key from public key and context"""
        return hashlib.sha256(public_key + self.PROTOCOL_NAME + context).digest()[:16]

    def get_derived_keys(self) -> Optional[Tuple[bytes, bytes]]:
        """Get derived send/recv keys after successful handshake"""
        if self.send_key and self.recv_key:
            return self.send_key, self.recv_key
        return None

    def reset(self):
        """Reset handshake state"""
        self.state = None
        self.send_key = None
        self.recv_key = None