#!/usr/bin/env python3
"""
TQWG TUN Interface - Windows Version
Uses WinTun or TAP-Windows
"""

import subprocess
import threading
import time
from typing import Optional

# Try WinTun (modern) or fallback to TAP
try:
    import wintun
    WINTUN_AVAILABLE = True
except ImportError:
    WINTUN_AVAILABLE = False


class TQWGTun:
    """Windows TUN interface"""
    
    def __init__(self, name: str = "tqwg0"):
        self.name = name
        self.session = None
        self.adapter = None
        self.mtu = 1400
        self._running = False
        self._receive_callback = None
        
    def create(self) -> bool:
        """Create TUN interface"""
        try:
            if WINTUN_AVAILABLE:
                # WinTun (recommended)
                self.adapter = wintun.create_adapter(self.name, "TQWG")
                self.session = self.adapter.start_session(0x400000)  # 4MB ring
                print(f"[*] Created WinTun adapter {self.name}")
            else:
                # TAP-Windows fallback (OpenVPN)
                self._create_tap()
                
            return True
            
        except Exception as e:
            print(f"[!] TUN creation failed: {e}")
            print("[!] Install WinTun or TAP-Windows driver")
            return False
    
    def _create_tap(self):
        """Fallback to TAP-Windows"""
        # Use tapctl from OpenVPN
        result = subprocess.run([
            "tapctl.exe", "create", 
            "--name", self.name
        ], capture_output=True, text=True)
        
        if result.returncode != 0:
            raise Exception(f"tapctl failed: {result.stderr}")
            
        print(f"[*] Created TAP adapter {self.name}")
    
    def configure(self, local_ip: str, peer_ip: str) -> bool:
        """Configure IP addresses"""
        try:
            if WINTUN_AVAILABLE and self.adapter:
                # WinTun uses netsh
                subprocess.run([
                    "netsh", "interface", "ip", "set", "address",
                    self.name, "static", local_ip, "255.255.255.0"
                ], check=True, capture_output=True)
                
                # Bring up
                subprocess.run([
                    "netsh", "interface", "set", "interface",
                    self.name, "enabled"
                ], check=True, capture_output=True)
                
            else:
                # TAP
                subprocess.run([
                    "netsh", "interface", "ip", "set", "address",
                    self.name, "static", local_ip, "255.255.255.0"
                ], check=True, capture_output=True)
            
            # Add route to peer
            subprocess.run([
                "route", "add", peer_ip, "mask", "255.255.255.255", local_ip
            ], capture_output=True)
            
            print(f"[*] Configured {self.name}: {local_ip} -> {peer_ip}")
            return True
            
        except Exception as e:
            print(f"[!] Configuration failed: {e}")
            return False
    
    def read(self) -> Optional[bytes]:
        """Read packet from TUN"""
        try:
            if WINTUN_AVAILABLE and self.session:
                return self.session.receive_packet()
            else:
                # TAP - would need different implementation
                return None
        except Exception as e:
            return None
    
    def write(self, data: bytes) -> bool:
        """Write packet to TUN"""
        try:
            if WINTUN_AVAILABLE and self.session:
                self.session.send_packet(data)
                return True
            return False
        except Exception as e:
            print(f"[!] TUN write error: {e}")
            return False
    
    def close(self):
        """Cleanup"""
        self._running = False
        if WINTUN_AVAILABLE:
            if self.session:
                self.session.close()
            if self.adapter:
                self.adapter.close()
        
        # Remove adapter
        try:
            subprocess.run([
                "tapctl.exe", "delete", self.name
            ], capture_output=True)
        except:
            pass