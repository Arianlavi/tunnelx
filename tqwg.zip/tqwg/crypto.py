#!/usr/bin/env python3
"""
TQWG Crypto Layer
Session-based encryption with ChaCha20-Poly1305
"""

import os
import struct
import time
import secrets
from typing import Optional, Dict
from dataclasses import dataclass, field

from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305


@dataclass
class CryptoSession:
    """Active cryptographic session"""
    session_id: bytes
    send_key: bytes
    recv_key: bytes
    nonce_send: int = 0
    nonce_recv: int = 0
    created_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)
    packets_sent: int = 0
    packets_recv: int = 0
    bytes_sent: int = 0
    bytes_recv: int = 0
    
    def is_expired(self, timeout: int = 300) -> bool:
        """Check if session expired due to inactivity"""
        return (time.time() - self.last_activity) > timeout
    
    def should_rekey(self, packet_limit: int = 100000, time_limit: int = 120) -> bool:
        """Check if rekeying is needed"""
        return (self.nonce_send > packet_limit or 
                (time.time() - self.created_at) > time_limit)
    
    def bump_activity(self):
        """Update last activity timestamp"""
        self.last_activity = time.time()


class TQWGCryptoSession:
    """
    TQWG Cryptographic Session Manager
    Handles encryption/decryption with automatic nonce management
    """
    
    SESSION_ID_SIZE = 16
    NONCE_SIZE = 12
    TIMESTAMP_SIZE = 8
    TAG_SIZE = 16
    HEADER_SIZE = TIMESTAMP_SIZE + NONCE_SIZE  # 20 bytes
    
    def __init__(self):
        self.sessions: Dict[bytes, CryptoSession] = {}
        self.current_session: Optional[CryptoSession] = None
    
    def create_session(self, send_key: bytes, recv_key: bytes) -> bytes:
        """Create new cryptographic session"""
        session_id = secrets.token_bytes(self.SESSION_ID_SIZE)
        
        session = CryptoSession(
            session_id=session_id,
            send_key=send_key,
            recv_key=recv_key
        )
        
        self.sessions[session_id] = session
        self.current_session = session
        
        return session_id
    
    def set_session(self, session_id: bytes):
        """Set current active session"""
        if session_id in self.sessions:
            self.current_session = self.sessions[session_id]
            self.current_session.bump_activity()
    
    def encrypt(self, plaintext: bytes, session_id: Optional[bytes] = None) -> Optional[bytes]:
        """
        Encrypt plaintext with session keys
        
        Format: [session_id(16)][timestamp(8)][nonce(12)][ciphertext+tag]
        """
        session = self.sessions.get(session_id) if session_id else self.current_session
        if not session:
            return None
        
        try:
            cipher = ChaCha20Poly1305(session.send_key)
            
            # Build nonce: 64-bit counter + 32-bit random
            counter_bytes = struct.pack("<Q", session.nonce_send)
            random_bytes = secrets.token_bytes(4)
            nonce = counter_bytes + random_bytes
            
            # Timestamp for replay protection
            timestamp = struct.pack(">Q", int(time.time()))
            
            # Associated data = timestamp
            ciphertext = cipher.encrypt(nonce, plaintext, timestamp)
            
            # Update session stats
            session.nonce_send += 1
            session.packets_sent += 1
            session.bytes_sent += len(plaintext)
            session.bump_activity()
            
            # Full packet
            return session.session_id + timestamp + nonce + ciphertext
            
        except Exception as e:
            print(f"[!] Encryption failed: {e}")
            return None
    
    def decrypt(self, packet: bytes) -> Optional[bytes]:
        """
        Decrypt packet and verify authenticity
        
        Returns plaintext or None if invalid
        """
        if len(packet) < (self.SESSION_ID_SIZE + self.HEADER_SIZE + self.TAG_SIZE):
            return None
        
        # Extract components
        session_id = packet[:self.SESSION_ID_SIZE]
        timestamp = packet[self.SESSION_ID_SIZE:self.SESSION_ID_SIZE + self.TIMESTAMP_SIZE]
        nonce = packet[self.SESSION_ID_SIZE + self.TIMESTAMP_SIZE:
                      self.SESSION_ID_SIZE + self.TIMESTAMP_SIZE + self.NONCE_SIZE]
        ciphertext = packet[self.SESSION_ID_SIZE + self.HEADER_SIZE:]
        
        # Find session
        session = self.sessions.get(session_id)
        if not session:
            return None
        
        # Anti-replay: check timestamp
        try:
            ts_val = struct.unpack(">Q", timestamp)[0]
            if abs(time.time() - ts_val) > 60:  # 60 second window
                return None
        except:
            return None
        
        # Decrypt
        try:
            cipher = ChaCha20Poly1305(session.recv_key)
            plaintext = cipher.decrypt(nonce, ciphertext, timestamp)
            
            # Update stats
            session.nonce_recv += 1
            session.bytes_recv += len(plaintext)
            session.bump_activity()
            
            return plaintext
            
        except Exception:
            return None
    
    def get_stats(self, session_id: Optional[bytes] = None) -> dict:
        """Get session statistics"""
        session = self.sessions.get(session_id) if session_id else self.current_session
        if not session:
            return {}
        
        return {
            'session_id': session_id.hex() if session_id else None,
            'created_at': session.created_at,
            'last_activity': session.last_activity,
            'packets_sent': session.packets_sent,
            'packets_recv': session.packets_recv,
            'bytes_sent': session.bytes_recv,
            'bytes_recv': session.bytes_recv,
            'nonce_send': session.nonce_send,
            'nonce_recv': session.nonce_recv,
            'is_expired': session.is_expired(),
            'should_rekey': session.should_rekey()
        }
    
    def remove_session(self, session_id: bytes):
        """Remove a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            if self.current_session and self.current_session.session_id == session_id:
                self.current_session = None
    
    def cleanup_expired(self):
        """Remove expired sessions"""
        expired = [
            sid for sid, sess in self.sessions.items() 
            if sess.is_expired()
        ]
        for sid in expired:
            self.remove_session(sid)
        return len(expired)