#!/usr/bin/env python3
"""
TQWG Transport Layer
Asyncio-based UDP transport with reliability
"""

import asyncio
import logging
from typing import Optional, Callable, Dict, Tuple
from dataclasses import dataclass
from enum import IntEnum

logger = logging.getLogger('TQWGTransport')


class PacketType(IntEnum):
    """Internal packet types"""
    DATA = 0
    ACK = 1
    KEEPALIVE = 2


@dataclass
class PendingPacket:
    """Packet waiting for ACK"""
    seq: int
    data: bytes
    addr: Tuple[str, int]
    timestamp: float
    retries: int = 0


class TQWGTransportProtocol(asyncio.DatagramProtocol):
    """UDP Protocol handler for TQWG"""

    def __init__(self, transport):
        self.transport = None
        self.tqwg_transport = transport

    def connection_made(self, transport):
        self.transport = transport
        self.tqwg_transport._protocol = self

    def datagram_received(self, data, addr):
        asyncio.create_task(self.tqwg_transport._handle_packet(data, addr))

    def error_received(self, exc):
        logger.error(f"Transport error: {exc}")


class TQWGTransport:
    """
    TQWG Transport Manager

    Handles UDP communication with optional reliability layer
    """

    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port

        self._protocol: Optional[TQWGTransportProtocol] = None
        self._on_packet: Optional[Callable[[bytes, Tuple], None]] = None

        # Reliability (optional)
        self.seq_send = 0
        self.seq_recv = 0
        self.pending_acks: Dict[int, PendingPacket] = {}
        self.ack_callback: Optional[Callable[[int], None]] = None

        self.running = False

    def set_packet_handler(self, callback: Callable[[bytes, Tuple], None]):
        """Set callback for received packets"""
        self._on_packet = callback

    async def start(self):
        """Start UDP transport"""
        loop = asyncio.get_event_loop()

        transport, protocol = await loop.create_datagram_endpoint(
            lambda: TQWGTransportProtocol(self),
            local_addr=(self.host, self.port)
        )

        self._protocol = protocol
        self.running = True

        logger.info(f"Transport started on {self.host}:{self.port}")

        return transport

    async def send(self, data: bytes, addr: Tuple[str, int],
                   reliable: bool = False) -> bool:
        """
        Send data to address

        Args:
            data: Payload to send
            addr: (host, port) tuple
            reliable: If True, wait for ACK

        Returns:
            True if sent successfully
        """
        if not self._protocol or not self._protocol.transport:
            logger.error("Transport not ready")
            return False

        try:
            if reliable:
                # Add reliability header
                seq = self.seq_send
                header = self._make_reliability_header(PacketType.DATA, seq)
                packet = header + data
                self.seq_send += 1

                # Track for ACK
                self.pending_acks[seq] = PendingPacket(
                    seq=seq, data=packet, addr=addr,
                    timestamp=asyncio.get_event_loop().time()
                )
            else:
                packet = data

            self._protocol.transport.sendto(packet, addr)
            return True

        except Exception as e:
            logger.error(f"Send failed: {e}")
            return False

    def _make_reliability_header(self, pkt_type: PacketType, seq: int) -> bytes:
        """Create reliability header"""
        # [type(1)][seq(4)][ack(4)]
        return bytes([pkt_type]) + seq.to_bytes(4, 'big') + (0).to_bytes(4, 'big')

    async def _handle_packet(self, data: bytes, addr: Tuple[str, int]):
        """Process received packet"""
        if len(data) < 1:
            return

        # Check if reliability packet
        pkt_type = data[0]

        if pkt_type == PacketType.ACK:
            # Process ACK
            if len(data) >= 5:
                seq = int.from_bytes(data[1:5], 'big')
                if seq in self.pending_acks:
                    del self.pending_acks[seq]
                    if self.ack_callback:
                        self.ack_callback(seq)
            return

        elif pkt_type in [PacketType.DATA, PacketType.KEEPALIVE]:
            # Extract payload (skip reliability header)
            if len(data) > 9:
                payload = data[9:]
                # Send ACK
                ack_seq = int.from_bytes(data[1:5], 'big')
                await self._send_ack(ack_seq, addr)
            else:
                payload = data

            # Call handler
            if self._on_packet:
                await self._on_packet(payload, addr)

    async def _send_ack(self, seq: int, addr: Tuple[str, int]):
        """Send ACK for received packet"""
        if self._protocol and self._protocol.transport:
            ack_packet = bytes([PacketType.ACK]) + seq.to_bytes(4, 'big')
            self._protocol.transport.sendto(ack_packet, addr)

    def get_stats(self) -> dict:
        """Get transport statistics"""
        return {
            'local_addr': f"{self.host}:{self.port}",
            'seq_send': self.seq_send,
            'seq_recv': self.seq_recv,
            'pending_acks': len(self.pending_acks),
            'running': self.running
        }

    def stop(self):
        """Stop transport"""
        self.running = False
        if self._protocol and self._protocol.transport:
            self._protocol.transport.close()