#!/usr/bin/env python3
"""
TQWG Server
Complete server implementation with auto-handshake
"""

import sys
import asyncio
import logging

from tqwg.protocol import TQWGProtocol
from tqwg.obfuscation import ObfMode

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


class TQWGServer:
    """TQWG VPN Server"""
    
    def __init__(self, host: str, port: int, obf_mode: ObfMode = ObfMode.XOR):
        self.protocol = TQWGProtocol(
            host=host,
            port=port,
            is_server=True,
            obf_mode=obf_mode
        )
        
        # Data handler
        self.protocol.set_data_handler(self._on_data)
        
        # Stats
        self.bytes_received = 0
        self.packets_received = 0
    
    def _on_data(self, data: bytes, addr: tuple):
        """Handle decrypted data from client"""
        self.packets_received += 1
        self.bytes_received += len(data)
        
        print(f"[<] {addr}: {len(data)} bytes | Total: {self.packets_received} pkts, {self.bytes_received} bytes")
        
        # TODO: Process VPN data (route to internet, NAT, etc.)
        # For now: echo back
        asyncio.create_task(self._echo_back(data, addr))
    
    async def _echo_back(self, data: bytes, addr: tuple):
        """Echo data back to client (for testing)"""
        response = b"ACK: " + data[:100]
        await self.protocol.send_data(response, addr)
    
    async def run(self):
        """Run server"""
        await self.protocol.start()
        
        print(f"\n{'='*50}")
        print("TQWG Server Running")
        print(f"{'='*50}")
        print(f"Server Key: {self.protocol.handshake.get_public_key_hex()}")
        print(f"{'='*50}\n")
        
        # Keep running
        try:
            while True:
                await asyncio.sleep(10)
                stats = self.protocol.get_stats()
                print(f"[Stats] Peers: {stats['authenticated']}, Packets: {self.packets_received}")
        except asyncio.CancelledError:
            pass


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python server.py <port> [obf_mode]")
        print("Modes: none, xor, tls, http, dns")
        sys.exit(1)
    
    port = int(sys.argv[1])
    
    # Parse obfuscation mode
    mode_str = sys.argv[2] if len(sys.argv) > 2 else "xor"
    mode_map = {
        'none': ObfMode.NONE,
        'xor': ObfMode.XOR,
        'tls': ObfMode.TLS_MIMIC,
        'http': ObfMode.HTTP_MIMIC,
        'dns': ObfMode.DNS_MIMIC
    }
    obf_mode = mode_map.get(mode_str, ObfMode.XOR)
    
    server = TQWGServer("0.0.0.0", port, obf_mode)
    
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        print("\n[*] Server stopped")