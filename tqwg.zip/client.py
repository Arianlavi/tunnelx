#!/usr/bin/env python3
"""
TQWG Client
Complete client implementation with auto-handshake
"""

import sys
import asyncio
import logging

from tqwg.protocol import TQWGProtocol
from tqwg.obfuscation import ObfMode

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


class TQWGClient:
    """TQWG VPN Client"""
    
    def __init__(self, server_host: str, server_port: int,
                 server_pubkey: str, obf_mode: ObfMode = ObfMode.XOR):
        
        self.server_addr = (server_host, server_port)
        self.server_pubkey = server_pubkey
        
        # Protocol (client mode)
        self.protocol = TQWGProtocol(
            host="0.0.0.0",
            port=0,  # Random port
            is_server=False,
            obf_mode=obf_mode
        )
        
        # Data handler
        self.protocol.set_data_handler(self._on_data)
        
        self.connected = False
        self.running = False
    
    def _on_data(self, data: bytes, addr: tuple):
        """Handle data from server"""
        print(f"[<] Server: {data[:200]}")
    
    async def connect(self) -> bool:
        """Connect to server"""
        await self.protocol.start()
        
        print(f"\n[*] Connecting to {self.server_addr}")
        print(f"[*] Server key: {self.server_pubkey[:32]}...")
        
        # Connect and handshake
        success = await self.protocol.connect_to(
            self.server_addr[0],
            self.server_addr[1],
            self.server_pubkey
        )
        
        if success:
            self.connected = True
            print("[+] Connected successfully!")
            return True
        else:
            print("[!] Connection failed")
            return False
    
    async def interactive(self):
        """Interactive mode"""
        if not await self.connect():
            return
        
        self.running = True
        
        print("\n[*] Interactive mode. Commands:")
        print("    /quit - Exit")
        print("    /stats - Show statistics")
        print("    <text> - Send message")
        print()
        
        while self.running:
            try:
                msg = await asyncio.get_event_loop().run_in_executor(
                    None, input, "> "
                )
                
                if msg == "/quit":
                    break
                elif msg == "/stats":
                    stats = self.protocol.get_stats()
                    print(f"Stats: {stats}")
                elif msg.startswith("/"):
                    print("Unknown command")
                else:
                    # Send data
                    success = await self.protocol.send_data(
                        msg.encode(), 
                        self.server_addr
                    )
                    if not success:
                        print("[!] Send failed")
                        
            except Exception as e:
                print(f"[!] Error: {e}")
        
        self.running = False
        print("[*] Disconnected")
    
    async def send_file(self, filepath: str):
        """Send file (future feature)"""
        pass


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python client.py <server_ip> <server_port> <server_pubkey> [obf_mode]")
        print("Example: python client.py 1.2.3.4 51820 a3f2b8... xor")
        sys.exit(1)
    
    host = sys.argv[1]
    port = int(sys.argv[2])
    pubkey = sys.argv[3]
    
    mode_str = sys.argv[4] if len(sys.argv) > 4 else "xor"
    mode_map = {
        'none': ObfMode.NONE,
        'xor': ObfMode.XOR,
        'tls': ObfMode.TLS_MIMIC,
        'http': ObfMode.HTTP_MIMIC,
        'dns': ObfMode.DNS_MIMIC
    }
    obf_mode = mode_map.get(mode_str, ObfMode.XOR)
    
    client = TQWGClient(host, port, pubkey, obf_mode)
    
    try:
        asyncio.run(client.interactive())
    except KeyboardInterrupt:
        print("\n[*] Exiting")